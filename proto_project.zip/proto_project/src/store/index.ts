import { createStore } from 'vuex'
import persistedState from 'vuex-persistedstate';
import app from './modules/index';
export default createStore({
    //持久化   默认localhost   换成sesstion
  plugins: [persistedState({
    storage: window.sessionStorage
  })],
  //模块导入
  modules: {
    app
  }
})

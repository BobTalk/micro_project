import { Module } from 'vuex'

const state = {
  layoutFlag: true
}
const getters = {
  getLayoutFlag: (state:obj) => state.layoutFlag
}
const mutations = {}
const actions = {}
const app: Module<any,any> = {
  namespaced: true,
  state,
  actions,
  getters,
  mutations
}
export default app

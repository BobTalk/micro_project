import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import '@/assets/css/index.styl'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css'
import { setupAntd } from './libs/ant-design'
// import antDesignVue from 'ant-design-vue';
const app = createApp(App)
setupAntd(app) // 注册ant-design
router.beforeEach((to, from, next) => {
    let isNProgress = ['/login', '/'].includes(to.path)
    if (isNProgress) {
        NProgress.start()
    }
    next()
})
router.afterEach(() => {
    NProgress.done()
})
app.use(store).use(router)
// 路由准备就绪后挂载APP实例
router.isReady().then(()=> app.mount('#app'))

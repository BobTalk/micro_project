import request from '@/axios/index';
// 登录
export function login(data: obj) {
  return request({
    url: '/api/login',
    method: 'post',
    data
  })
}
// 注册
export function register(data: obj) {
  return request({
    url: '/api/register',
    method: 'post',
    data
  })
}

import request from '@/axios/index';
// 登录
export function getNavBar() {
  return request({
    url: '/api/getNavBar',
    method: 'get'
  })
}

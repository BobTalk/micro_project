<template>
  <menu-fold-outlined v-if="moduleData.collapsed" class="trigger" @click="cbhandler" />
  <menu-unfold-outlined  v-else class="trigger" @click="cbhandler" />
</template>

<script lang="ts">
import { MenuUnfoldOutlined, MenuFoldOutlined } from '@ant-design/icons-vue'
import { defineComponent, reactive } from 'vue'
export default defineComponent({
  name: 'Header',
  components: {
    MenuUnfoldOutlined,
    MenuFoldOutlined,
  },
  setup(props, context: any) {
    const moduleData= reactive({
      collapsed: true
    })
    const cbhandler = () => {
      moduleData.collapsed = !moduleData.collapsed
      context.emit('collapsedChange')
    }
    return {
      cbhandler,
      moduleData
    }
  },
})
</script>

<style lang="stylus" scope>
.trigger {
  font-size: 18px;
  line-height: 64px;
  padding: 0 24px;
  cursor: pointer;
  transition: color 0.3s;
}
</style>

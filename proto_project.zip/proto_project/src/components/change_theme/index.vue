<template>
  <div class='hq-theme'>
    <a-button type='primary' @click='updatePrimaryColor'>改变主题</a-button>
  </div>
</template>

<script lang='ts'>
import { defineComponent } from 'vue'
export default defineComponent({
    name: 'Login',
    methods: {
        updatePrimaryColor() {
            (window as any).less.modifyVars({
                'primary-color': 'blue',
                'btn-primary-bg': '#5d72cc'
            }).then((res: any) => {
                console.log('成功')
            }).catch((res: any) => {
                console.log('错误')
            })
        }
    }
})
</script>
<style lang='stylus' scoped>

</style>

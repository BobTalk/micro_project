<template>
<ul class="message-list">
    <li :class="`message-item ${setClass(item.type)}`" v-for="(item, index) in messageList" :key="index">
       <em :class="`iconfont ${setIcon(item.type)}`" /> {{ item.title }}
    </li>
</ul>
</template>

<script lang="ts">
import {
    reactive,
    defineComponent
} from 'vue'

interface MessageList {
    type: string
    title: string
}

export default defineComponent({
    props: {
        messageList: {
            type: Array,
            default: () => []
        }
    },
    setup() {
      function setIcon(type: string): string{
        if (type === 'info') {
                return 'iconxinxi'
            } else if (type === 'wraning') {
                return 'iconziyuan'
            } else if (type === 'success') {
                return 'iconzhengque'
            } else if (type === 'error') {
                return 'iconcuowu'
            }
            return ''
      }
        function setClass(type: string): string {
            if (type === 'info') {
                return 'message-info-item'
            } else if (type === 'wraning') {
                return 'message-wraning-item'
            } else if (type === 'success') {
                return 'message-success-item'
            } else if (type === 'error') {
                return 'message-error-item'
            }
            return ''
        }
        return {
            setClass,
            setIcon
        }
    }
})
</script>

<style lang="stylus" scoped>
.message-list {
    position: fixed;
    top: 0;
    left: 50%;
    z-index: 1000;
    margin-bottom: 0;
    transform: translateX(-50%);

    .message-item {
        display: block;
        margin-top: 10px;
        padding: 5px 24px 5px 10px;
        border: 1px solid #b3d0cf;
        background-color: #e6f3ff;
        font-size: 14p;
        color: #007bff;
        text-align: left;
        box-shadow: 0 1px 1px 0 hsla(0, 0%, 80.4%, 0.5);
        border-radius: 2px;
        cursor: default;
    }

    .message-info-item {
        border: 1px solid #b3d0cf;
        background-color: #e6f3ff;
        color: #007bff;
    }

    .message-error-item {
        border: 1px solid #e99;
        background-color: #f6e3e3;
        color: #e33;
    }
}
</style>

<template>
  <a-menu
    :default-selected-keys="['1']"
    mode="inline"
    theme="dark"
    v-model:selectedKeys="moduleDatas.selectedKeys"
  >
    <a-menu-item key="1">
      <user-outlined />
      <span>nav 1</span>
    </a-menu-item>
    <a-menu-item key="2">
      <video-camera-outlined />
      <span>nav 2</span>
    </a-menu-item>
    <a-menu-item key="3">
      <upload-outlined />
      <span>nav 3</span>
    </a-menu-item>
  </a-menu>
</template>
<script lang="ts">
import { UserOutlined, VideoCameraOutlined, UploadOutlined } from '@ant-design/icons-vue'
import { getNavBar } from '../../api/navbar'
import { defineComponent, reactive } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import Message from '../../components/message/index'
export default defineComponent({
  name: 'NavBar',
  props: {},
  components: {
    UserOutlined,
    VideoCameraOutlined,
    UploadOutlined,
  },
  setup() {
    const router = useRouter()
    const route = useRoute()
    const moduleDatas = reactive({
      navBarList: [],
      selectedKeys: ['1'],
    })
    // 获取nav数据
    getNavBar().then((res: obj) => {
      console.log(res)
      if (res.success) {
        moduleDatas.navBarList = res.data
      } else {
        Message.wraning(res.msg)
      }
    })
    const jumpHandler = (currentData: { path: string }): void => {
      // 当前地址与跳转地址一致时 return
      if (route.path == currentData.path) return
      router.push({
        path: currentData.path,
      })
    }
    return {
      moduleDatas,
      jumpHandler,
    }
  },
})
</script>
<style lang="stylus" scoped>
:deep(.ant-menu-item){
    height: 36px;
    padding: 0 10px;
  }

.hq-nav-item {
  display: flex;
  background: var(--blue);
  color: var(--white);
  height: 36px;
  align-items: center;
  padding: 0 10px;
}
</style>

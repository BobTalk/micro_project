import {
  Button,
  Form,
  Input,
  Radio,
  Layout,
  Menu,
  Icon
} from 'ant-design-vue'

export function setupAntd(app: any) {
  app.use(Button)
    .use(Form)
    .use(Input)
    .use(Radio)
    .use(Layout)
    .use(Menu)
    .use(Icon)
}

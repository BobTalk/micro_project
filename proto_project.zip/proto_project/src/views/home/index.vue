<template>
  <div>
home
  </div>
</template>

<script>
import { defineComponent } from 'vue';
export default defineComponent({
  name:'Home',
  setup(){}
})
</script>

<style>

</style>

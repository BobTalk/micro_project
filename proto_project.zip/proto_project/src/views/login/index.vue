<template>
  <div class="hq-login">
    <div class="login-box">
      <div class="user-info">
        <div class="info-name">
          <p>用户名:</p>
          <p v-show="modelRef.registerFlag">手机号:</p>
          <p v-show="modelRef.registerFlag">性&ensp;别:</p>
          <p>密&ensp;码:</p>
          <p v-show="modelRef.registerFlag">确认密码:</p>
        </div>
        <div class="info-coll">
          <p>
            <a-input v-model:value="modelRef.userName" placeholder="userName" />
          </p>
          <p v-show="modelRef.registerFlag">
            <a-input v-model:value="modelRef.phone" placeholder="phone" />
          </p>
          <p class="sex" v-show="modelRef.registerFlag">
            <a-radio-group :options="modelRef.plainOptions" v-model:value="modelRef.gender"></a-radio-group>
            <!-- <span :key='key' v-for="(item, key) in modelRef.plainOptions" class="center">
                        <input type="radio" name='gender' ref="JGender" :value="item.value" :checked='item.value == key' @click="valChangeHandler">
                        <span>{{item.label}}</span>
            </span>-->
          </p>
          <p>
            <a-input-password v-model:value="modelRef.password" placeholder="password"></a-input-password>
          </p>
          <p v-show="modelRef.registerFlag">
            <a-input-password v-model:value="modelRef.comfirPassword" placeholder="comfirPassword"></a-input-password>
          </p>
        </div>
      </div>
      <div class="btn-group">
        <a-button type="primary" @click="submitLogin()">{{modelRef.submitBtn}}</a-button>
        <a-button type="primary" @click="regiterLogin">注&ensp;册</a-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { reactive, toRaw, defineComponent, ref } from 'vue'

import { useForm } from '@ant-design-vue/use'
import { useRouter, useRoute } from 'vue-router'
import { login, register } from '../../api/login'
import Message from '../../components/message/index'
import { setSession } from '../../utils/base'
export default defineComponent({
  name: 'Login',
  setup(props, content) {
    const router = useRouter()
    const route = useRoute()
    const modelRef = reactive({
      userName: '',
      password: '',
      phone: '',
      comfirPassword: '',
      gender: '',
      plainOptions: [
        {
          label: '男',
          value: 1,
        },
        {
          label: '女',
          value: 0,
        },
      ],
      registerFlag: false,
      submitBtn: '确认',
    })
    // 登录
    const submitLogin = () => {
      if (modelRef.registerFlag) {
        // 注册页面登录事件
        register({
          userName: modelRef.userName,
          password: modelRef.password,
          phone: modelRef.phone,
          gender: modelRef.gender,
          isRegister: true,
        }).then((res: any) => {
          if (!res?.success) {
            modelRef.registerFlag = false
            Message.wraning(res.msg)
          }
        })
        return
      }
      // 登录
      login({
        userName: modelRef.userName,
        password: modelRef.password,
        isRegister: false,
      }).then((res: any) => {
        console.log(res)
        if (!res.success) {
          Message.error(res.msg)
          return
        }
        setSession('Authorization', res.token)
        router.replace({
          path: '/home',
          params: {
            redirect: route.fullPath,
          },
        })
      })
    }
    // 注册
    const regiterLogin = () => {
      modelRef.registerFlag = true
      modelRef.submitBtn = '提交'
    }
    return {
      modelRef,
      submitLogin,
      regiterLogin,
    }
  },
})
</script>

<style lang="stylus" scoped>
.hq-login {
  width: 100%;
  height: 100%;
  background-color: #195a19;
  /* 浏览器不支持的时候显示 */
  background-image: radial-gradient(circle, #08f108 20%, #1bce1b 50%, #20ab20 20%, #1e821e 20%, #195a19);
}

.login-box {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.user-info {
  display: flex;
}

.info-name, .info-coll {
  p {
    margin: 0 10px 15px 0;
    text-align: right;
    height: 30px;
    line-height: 30px;
    box-sizing: border-box;

    &:last-child {
      margin-bottom: 0;
    }
  }
}

.info-coll {
  p {
    position: relative;
    margin-right: 0;
    box-sizing: border-box;
  }

  :deep(.ant-input-suffix) {
    position: absolute;
    right: 12px;
  }

  :deep(.ant-input-affix-wrapper) {
    border: 0;

    &:hover {
      border: 0;
    }
  }

  :deep(.ant-input-affix-wrapper-focused) {
    box-shadow: none;
  }
}

:deep(.ant-input) {
  height: 30px;
  width: 200px;
  padding: 5px 10px;
  border: none !important;

  &:hover {
    border-color: transparent;
    border-right-width: 0 !important;
  }

  &:focus {
    border-color: transparent;
    border-right-width: 0 !important;
    box-shadow: none;
  }
}

.btn-group {
  display: flex;
  justify-content: center;
  margin-top: 15px;

  .ant-btn {
    margin-right: 10px;
    padding: 5px 10px;
    cursor: pointer;

    &:last-child {
      margin-right: 0;
    }
  }
}

:deep(.ant-radio-group) {
  display: flex;

  .ant-radio-inner {
    border: none;
    margin-right: 5px;
  }
}

.sex {
  display: flex;
  font-size: 14px;

  input[type='radio'] {
    margin-right: 2px;
  }
}

:deep(.ant-radio-wrapper) {
  display: inline-flex;
  align-items: center;

  &:nth-child(odd) {
    margin-right: 10px;
  }
}
</style>

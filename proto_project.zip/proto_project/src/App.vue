<template>
  <template v-if='layoutFlag'>
      <layout-comp></layout-comp>
  </template>
  <template v-else>
      <router-view />
  </template>
</template>
<script lang="ts">
import { defineComponent, computed } from 'vue'
import {useStore} from 'vuex'
import layoutComp from './views/layout/index.vue';
export default defineComponent({
  name: "App",
  components:{
    layoutComp
  },
  setup(props) {
    const store = useStore()
    console.log(store)
   const layoutFlag = computed(() => {
      return store.getters['app/getLayoutFlag']
    })
    return {
      layoutFlag
    }
  }
})
</script>
<style lang="stylus">
@import './assets/css/iconfont.css'
#app{
  width: inherit;
  height: inherit;
  overflow: auto;
}
</style>

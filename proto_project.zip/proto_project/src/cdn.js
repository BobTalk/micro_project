module.exports = {
    dev: [
        'https://cdn.bootcdn.net/ajax/libs/vue/2.6.11/vue.common.dev.js',
        'https://cdn.bootcdn.net/ajax/libs/vue-router/3.2.0/vue-router.js'
    ],
    prod: [
        'https://cdn.bootcdn.net/ajax/libs/vue/2.6.11/vue.min.js',
        'https://cdn.bootcdn.net/ajax/libs/vue-router/3.2.0/vue-router.min.js'
    ],
    mapping: {
        'vue': 'Vue',
        'vue-router': 'VueRouter'
    }
}

const sessionStorage = window.sessionStorage
const JSON = window.JSON
// 获取session
export function getSession(name: string): string | object {
    let value: any = sessionStorage.getItem(name)
    try {
        value = JSON.parse(value)
        return value
    } catch (error) {
        return value
    }
}
// 设置session
export function setSession(name: string, value: any): void {
    if (typeof value === 'object') value = JSON.stringify(value)
    sessionStorage.setItem(name, value)
}
// 移除session
export function removeSession(name: string) {
    return sessionStorage.removeItem(name)
}
// 清除全部session
export function clearSession() {
    sessionStorage.clear()
}
// 是否有父级
export function isParent(children: obj, parent: any) {
    if (!parent) return false
    while (children) {
        if (children === parent) return true
        children = children.parentNode
    }
    return false
}
// 字符串截取
export function subStringFn(str: string, strLength: number) {
    if (typeof str === 'string' && str.length > strLength) {
        str = str.substring(0, strLength) + '...'
    } else {
        console.warn('{$str} 不是字符串！')
    }
    return str
}
//    yyyy-MM-dd 转时间戳
export function formatTime(str: string) {
    return Number((new Date(str.replace(/[-\\/]/g, '/'))).getTime())
}
// 天转时间戳
export function formatDay(str: number) {
    return Number(str * 24 * 60 * 60 * 1000)
}
// 时间戳转yyyy-MM-dd
export function formatYMD(str: string) {
    var date = new Date(str)// 时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var year = date.getFullYear()
    var month = String(date.getMonth() + 1).padStart(2, '0')
    var dateT = String(date.getDate()).padStart(2, '0')
    var hour = String(date.getHours()).padStart(2, '0')
    var minute = String(date.getMinutes()).padStart(2, '0')
    var second = String(date.getSeconds()).padStart(2, '0')
    return year + '-' + month + '-' + dateT + ' ' + hour + ':' + minute + ':' + second
}
// 时间格式化
export function formatDate(time: string, format: string) {
    if (!time) {
        return ''
    }
    time = time.trim() // 清除前后空格
    const Reg = /^(\d{4})[-|/|年]([0][1-9]|[1][0-2])[-|/|月]([1-9]|[012]\d|3[01])\s*(\d{0,2}):(\d{0,2}):(\d{0,2})$/gi
    var timeArray: any = Reg.exec(time)
    var year, month, day
    year = timeArray[1]// 年
    month = timeArray[2]// 月
    day = timeArray[3]// 日
    if (format) {
        return year + format + month + format + day
    }
    return year + '-' + month + '-' + day

}
// 深拷贝
export function deepCopy(objectData: obj, weakMap = new WeakMap()) {
    if (weakMap.has(objectData)) { return weakMap.get(objectData) }
    if (objectData === null) { return null }
    if (objectData instanceof RegExp) { return new RegExp(objectData) }
    if (objectData instanceof Date) { return new Date(objectData) }
    if (typeof objectData !== 'object') { return objectData }
    const res = new objectData.__proto__.constructor()
    weakMap.set(objectData, res)
    for (const key in objectData) {
        // eslint-disable-next-line no-undef
        res[key] = deepCopy(objectData[key], weakMap)
    }
    return res
}
// 对象数据去重
export function uniqueArrObj(arr: [], uniqueFlag: string) {
    const tempArr:[] = []
    const uniqueVal:[] = []
    for (const item of arr) {
        if (uniqueVal.includes(item[uniqueFlag])) continue
        uniqueVal.push(item[uniqueFlag])
        tempArr.push(item)
    }
    return tempArr
}
// 数组拆分
export function arrSplit(arr:[], size: number) {
    return arr.length ? arr.reduce((t, v) => (t[t.length - 1].length === size ? t.push([v]) : t[t.length - 1].push(v), t), [[]]) : []
}
// 防抖
export function debounce(fn: Function, wait = 3000, immediate = false) {
    let timeout: number, result: any
    const debounced = function(this: any) {
        const context = this
        const args = arguments
        if (timeout) clearTimeout(timeout)
        if (immediate) {
            // 已经执行过了 则不在执行
            const callNow = !timeout
            timeout = setTimeout(function() {
                timeout = 0
            }, wait)
            if (callNow) result = fn.apply(context, args)
        } else {
            timeout = setTimeout(function() {
                fn.apply(context, args)
            }, wait)
        }
        return result
    }
    // 手动清除定时器
    debounced.cancle = function() {
        clearTimeout(timeout)
        timeout = 0
    }
    return debounced
}
//  千分符参数
export function thousands(num:number) {
    if (typeof num === 'string' || typeof num === 'number') {
        return (num.toString().indexOf('.') !== -1) ? Number(num).toLocaleString() : num.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
    }
    return num
}
// 路径参数解析
export function getQueryObject(url:string) {
    url = url == null ? window.location.href : url
    var search = url.substring(url.lastIndexOf('?') + 1)
    var objData:obj = {}
    var reg = /([^?&=]+)=([^?&=]*)/g
    search.replace(reg, function(rs, $1, $2) {
        var name = decodeURIComponent($1)
        var val = decodeURIComponent($2)
        val = String(val)
        objData[name] = val
        return rs
    })
    return objData
}
// 对象转formadata
export function jsToFormData(objData: obj, key: string) {
    let formData = new FormData()
    if (Array.isArray(objData)) {
        for (let i of objData) {
            formData.append(key, i)
        }
    }
    return formData
}
// 下载
export function download(name:string, data:any, type:string) {
    const element:HTMLElement = document.createElementNS('http://www.w3.org/1999/xhtml', 'a')
    const ev = document.createEvent('MouseEvents')
    const urlObject = window.URL || window.webkitURL || window
    const export_blob = new Blob([data], {type: type || ''})
    element.href = urlObject.createObjectURL(export_blob)
    element.download = name
    ev.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null)
    element.dispatchEvent(ev)
    urlObject.revokeObjectURL(element.href)
    element.href = ''
}

export function sortObj(sourceData:[], propertyName:string) {
    let sourceDataCopy = deepCopy(sourceData)
    let type = Object.prototype.toString.call(sourceDataCopy).slice(8, -1)
    if (type === 'Array') {
        sourceDataCopy.sort((a:any, b:any) => a[propertyName].localeCompare(b[propertyName]))
    }
    return sourceDataCopy
}

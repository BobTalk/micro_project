interface obj {
  [key:string]: any
}
interface HTMLElement {
  [key:string]: any
}

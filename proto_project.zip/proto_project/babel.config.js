module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
  "plugins": [
    [
      "import", {
        "libraryName": "ant-design-vue",
        "libraryDirectory": "es",  // default: lib es
        "style": true   // or 'css'  true => .less
      }
    ]
  ]
}
